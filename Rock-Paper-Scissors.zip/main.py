from random import randint
t=['rock','paper','scissors']
computer=t[randint(0,2)]
player=False
while player==False:
    player=input("rock,paper,scissors? ").lower()
    if player==computer:
        print("Tie!")
    elif player=="rock".lower():
        if computer=="paper":
            print("Sucks, dude,",computer,"covers",player)
        else:
            print("Yay!",player,"smashes",computer)
    elif player=="Paper".lower():
        if computer=="Scissors":
            print("Sucks, dude,",computer,"cut",player)
        else:
            print("Yay!",player,"covers",computer)
    elif player=="Scissors".lower():
        if computer=="Rock":
            print("Sucks, dude,",computer,"smashes",player)
        else:
            print("Yay!",player,"cut",computer)
    else:
        print("That's not a valid play.Check your spelling!")
    player=False
    computer=t[randint(0,2)]