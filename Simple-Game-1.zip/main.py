print("Welcome to Game 1")

'''
variables are not in quotation marks
Ignoring is done by the triple quotation marks
str("left" "right" "56")
int(5, 6, 7)
Float(5.5, 6.5)
Bool(True, False)
'''

hi = "right or left"
name = input("What is your name? ")
age = int(input("What is your age? "))
location = input("Where are you from? ")
print("Hello", name ,"aged", age ,"from" , location,)

if age >= 18:
  print("time to start playing!")
  wants_to_play = input("Are you ready? (yes or no) ").lower()
  if wants_to_play == "yes":
    print("Let's get it, son")

    left_or_right = input("Which direction do you want to start with? (left or right)" ).lower()
    if left_or_right == "right":
      print("you enter into a dark, moist hallway") 
      
      bag_choice = input("What do you grab from your bag, flashlight or chalk? ").lower()
      if bag_choice == "chalk":
        print("you begin scaling the walls and make it to safety")
      if bag_choice == "flashlight":
        print("the light agitated a tiny aligator who came up and ate you")
    else: print("Wow, dude, you managed to fall off the map in the first move")
    print("End of game," , name)

      


  else:
    print("K, whatevs, dude. ")
elif age >= 16:
  print("play with a parent")
else:
  print("come back in" , 18-age, "years when you are old enough to play")
